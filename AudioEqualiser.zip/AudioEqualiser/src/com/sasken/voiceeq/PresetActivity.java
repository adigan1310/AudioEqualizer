package com.sasken.voiceeq;

import java.util.ArrayList;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.VerticalSeekBar;
import edu.emory.mathcs.jtransforms.fft.DoubleFFT_1D;

public class PresetActivity extends Activity implements OnSeekBarChangeListener{
	public static final int SEEKMAX = 10;
	
	int bands[];
	static int trackID, recordID;
	boolean isRecording = false;
	boolean humanOnly = false;
	
	int selectedPreset;
	AudioRecord arec;
	AudioTrack atrack;

	ImageView imageView;
	Bitmap bitmap;
	Canvas canvas;
	Paint paint;
	int bufferSize;

	int FFT_SIZE;
	DoubleFFT_1D mFFT;
	double[] audioBuffer;
	DBHelper db ;
	ArrayList<SpinnerData> presetNames;
	Spinner s;
	float bandValues[];
	VerticalSeekBar vsb[];
	TextView frequencies[];
	boolean beep[];
	Context context = this;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_preset);
		CheckBox cb1 = (CheckBox) findViewById(R.id.checkBox1);
		bufferSize = 4096;
		imageView = (ImageView) this.findViewById(R.id.imageView1);
		bitmap = Bitmap.createBitmap(400, 100, Bitmap.Config.ARGB_8888);
		canvas = new Canvas(bitmap);
		paint = new Paint();
		paint.setColor(Color.YELLOW);
		imageView.setImageBitmap(bitmap);
		db = new DBHelper(this);
		
		bands = new int[SEEKMAX];
		bandValues = new float[SEEKMAX];
		vsb = new VerticalSeekBar[SEEKMAX];
		frequencies = new TextView[SEEKMAX];
		beep = new boolean[SEEKMAX];
		LinearLayout layout = (LinearLayout) findViewById(R.id.seekBarLayout);
		LinearLayout freqDispLayout = (LinearLayout) findViewById(R.id.linear);
		s = (Spinner) findViewById(R.id.spinner1);

		for (int i = 0; i < SEEKMAX; i++) {
			vsb[i] = new VerticalSeekBar(this);
			vsb[i].setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
					LayoutParams.MATCH_PARENT));
			layout.addView(vsb[i]);
			frequencies[i] = new TextView(this);
			frequencies[i].setWidth(100);
			frequencies[i].setText(""+(80+ i * 142));
			freqDispLayout.addView(frequencies[i]);
			
			vsb[i].setOnSeekBarChangeListener(this);
		}
		TextView v = new TextView(this);
		v.setText(" Hz");
		freqDispLayout.addView(v);
		((Button) findViewById(R.id.button1))
		.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				for (int i = 0; i < SEEKMAX; i++) {
					vsb[i].setProgressAndThumb(vsb[i].getMax() / 2);
				}
			}
		});
		cb1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (((CheckBox) arg0).isChecked()) {
					if (!isRecording) {
						isRecording = true;
						new AudioServiceTask().execute();
					}
				} else {
					isRecording = false;
				}
			}
		});
		Button b4 = (Button) findViewById(R.id.button5);
		b4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				final Dialog dialog = new Dialog(context);
				dialog.setContentView(R.layout.save_preset);
				dialog.setTitle("Set Preset Name");
				Button saveButton = (Button) dialog.findViewById(R.id.button4);
				final EditText ed1 = (EditText) dialog.findViewById(R.id.editText1);
				saveButton.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						for(int i = 0; i < SEEKMAX; i++) {
							bands[i] = vsb[i].getProgress();
						}
						db.insertPreset(ed1.getText().toString(), bands);
						populateSpinner();
						dialog.dismiss();
					}
				});
				
				dialog.show();
			}
		});
		
		s.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				
				Cursor cs = db.getData(presetNames.get(arg2).getId());
				cs.moveToFirst();
				for(int i=0; i < SEEKMAX; i++) {
					vsb[i].setProgressAndThumb(cs.getInt(cs.getColumnIndex(DBHelper.PRESET_COLUMN_BAND[i])));
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
				
		populateSpinner();
	}
	
	private void populateSpinner() {
		presetNames = db.getAllPresets();
		ArrayAdapter adapter = new ArrayAdapter<SpinnerData>(this, android.R.layout.simple_spinner_item, presetNames);
		s.setAdapter(adapter);
	}
	
	private class AudioServiceTask extends AsyncTask<Void, double[], Integer> {

		@Override
		protected Integer doInBackground(Void... arg0) {
			arec = new AudioRecord(MediaRecorder.AudioSource.MIC, 11025,
					AudioFormat.CHANNEL_IN_MONO,
					AudioFormat.ENCODING_PCM_16BIT, bufferSize);
			atrack = new AudioTrack(AudioManager.STREAM_VOICE_CALL, 11025,
					AudioFormat.CHANNEL_OUT_MONO,
					AudioFormat.ENCODING_PCM_16BIT, bufferSize,
					AudioTrack.MODE_STREAM);
			atrack.setPlaybackRate(11025);
			trackID = atrack.getAudioSessionId();
			recordID = arec.getAudioSessionId();
			Log.d("TAG", "Track ID:" + atrack.getAudioSessionId());
			short[] buffer = new short[bufferSize / 2];
			arec.startRecording();
			atrack.play();
			Log.d("TAG", "STARTED");
			Log.d("BUFFER SIZE:", "" + bufferSize);

			FFT_SIZE = 2048 / 2;
			mFFT = new DoubleFFT_1D(FFT_SIZE);
			audioBuffer = new double[2048];

			while (isRecording) {
				int bufferReadResult = arec.read(buffer, 0, bufferSize / 2);

				buffer = applyFilter(buffer, bufferReadResult, 11025);

				atrack.write(buffer, 0, bufferSize / 2);
			}

			return 1;
		}
		private short[] applyFilter(short[] buffer, int bufferReadResult,
				int sampleRate) {

			double[] window = new double[bufferReadResult];
			for (int i = 0; i < bufferReadResult; i++) {
				window[i] = 0.54 - 0.46 * Math.cos(i * 2 * Math.PI/ (bufferReadResult - 1)); // hamming window
//				 window[i] = 1; //rectangular window
				// window[i] = 0.5 * (1 -
				// Math.cos(i*2*Math.PI/(bufferReadResult-1))); //hann window
				// window[i] = Math.cos((Math.PI/(bufferReadResult-1)) -
				// Math.PI/2); //cosine window
				// window[i] = 1 - Math.abs(1 - (2/(bufferReadResult-1))); //triangular window
				audioBuffer[i] = (double) (buffer[i] * window[i]) / 32768.0;
			}

			mFFT.realForward(audioBuffer);
			

			for (int fftBin = 0; fftBin < FFT_SIZE; fftBin++) {

				float frequency = (float) (fftBin * sampleRate)
						/ (float) FFT_SIZE;
				boolean flag = false;

				float minFreq = 80;
				float maxFreq = 1499;

				if (frequency > minFreq && frequency < maxFreq)
					flag = true;

				if (flag) {
					int real = 2 * fftBin;
					int imaginary = 2 * fftBin + 1;
					int i = (int)Math.floor((frequency-80)/142);
					
					
					
					if (beep[i] == false) {
						audioBuffer[real] = audioBuffer[real] * bandValues[i];
						audioBuffer[imaginary] = audioBuffer[imaginary] * bandValues[i];
					} else {
						audioBuffer[real] = 5 * bandValues[i];
						audioBuffer[imaginary] = 5 * bandValues[i];
					}
				}
			}
			
			if(humanOnly) {
				for (int fftBin = 0; fftBin < FFT_SIZE; fftBin++) {
	
					float frequency = (float) (fftBin * sampleRate)
							/ (float) FFT_SIZE;
					boolean flag = false;
	
					float minFreq = 80;
					float maxFreq = 1499;
	
					if (frequency < minFreq || frequency > maxFreq)
						flag = true;
	
					if (flag) {
						int real = 2 * fftBin;
						int imaginary = 2 * fftBin + 1;
						//int i = (int)Math.floor((frequency-80)/142);
						
						audioBuffer[real] = audioBuffer[real] * 0.25;
						audioBuffer[imaginary] = audioBuffer[imaginary] * 0.25;
					}
				}
			}
			
			

			publishProgress(audioBuffer);

			mFFT.realInverse(audioBuffer, true);

			for (int i = 0; i < bufferReadResult; i++) {

				window[i] = 0.54 - 0.46 * Math.cos(i * 2 * Math.PI/ (bufferReadResult - 1)); // hamming window
//				 window[i] = 1; //rectangular window
				// window[i] = 0.5 * (1 -
				// Math.cos(i*2*Math.PI/(bufferReadResult-1))); //hann window
				// window[i] = Math.cos((Math.PI/(bufferReadResult-1)) -
				// Math.PI/2); //cosine window
				// window[i] = 1 - Math.abs(1 - (2/(bufferReadResult-1)));
				// //triangular window
				buffer[i] = (short) (audioBuffer[i] * 32768 / window[i]);
			}

			return buffer;
		}
			@Override
			protected void onProgressUpdate(double[]... audioBuffer) {
				// TODO Auto-generated method stub
				canvas.drawColor(Color.BLACK);
				int freq1 = 80 * FFT_SIZE / 11025;
				int freq2 = 1500 * FFT_SIZE / 11025;
				for (int i = freq1; i < freq2; i++) {
					int x = i * 3;
					int downy = (int) (100 - ((audioBuffer[0][2 * i]) * 10));
					int upy = 100;
					for (int j = 0; j < 3; j++) {
						canvas.drawLine(x + j, downy, x + j, upy, paint);
					}

				}

				imageView.invalidate();
			}

			@Override
			protected void onPostExecute(Integer result) {
				arec.stop();
				arec.release();
				atrack.stop();
				atrack.release();

			}
		}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
		// TODO Auto-generated method stub
		for (int i = 0; i < SEEKMAX; i++) {
			if (arg0 == vsb[i]) {
				bandValues[i] = (float)arg1 / (float)(vsb[i].getMax() / 2);
			}
		}
	}

	@Override
	public void onStartTrackingTouch(SeekBar arg0) {
		// TODO Auto-generated method stub
		for(int i=0; i<SEEKMAX; i++) {
			if(arg0 == vsb[i]) {
				beep[i] = true;
			}
		}
	}

	@Override
	public void onBackPressed() {
	    isRecording=false;
		super.finish();
	}
	@Override
	public void onStopTrackingTouch(SeekBar arg0) {
		for(int i=0; i<SEEKMAX; i++) {
			if(arg0 == vsb[i]) {
				beep[i] = false;
			}
		}
	}
}
