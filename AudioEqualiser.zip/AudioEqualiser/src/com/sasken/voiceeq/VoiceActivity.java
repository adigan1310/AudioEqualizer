package com.sasken.voiceeq;

import java.util.ArrayList;
import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import edu.emory.mathcs.jtransforms.fft.*;

public class VoiceActivity extends Activity {
	static int trackID, recordID;
	boolean isRecording = false;
	boolean humanOnly = false;

	AudioRecord arec;
	AudioTrack atrack;
	private int sampleRate = 11025;

	ImageView FilteredView;
	Bitmap bitmap;
	Canvas canvas;
	Paint paint;
	int bufferSize;
	final int SEEKMAX = PresetActivity.SEEKMAX;
	int FFT_SIZE;
	DoubleFFT_1D mFFT;
	static double[] audioBuffer;

	float bandValues[];
	
	DBHelper db ;
	ArrayList<SpinnerData> presetNames;
	private Spinner presets;
	private ImageView UnfilteredView;
	private Bitmap ubitmap;
	private Canvas ucanvas;
	private Paint upaint;
	
	private void populateSpinner() {
		presetNames = db.getAllPresets();
		ArrayAdapter adapter = new ArrayAdapter<SpinnerData>(this, android.R.layout.simple_spinner_item, presetNames);
		presets.setAdapter(adapter);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_voice);
		CheckBox cb1 = (CheckBox) findViewById(R.id.checkBox1);
		CheckBox cb2 = (CheckBox) findViewById(R.id.checkBox2);
		bufferSize = 4096;
		FilteredView = (ImageView) this.findViewById(R.id.imageView2);
		UnfilteredView = (ImageView) this.findViewById(R.id.imageView1);
		bitmap = Bitmap.createBitmap(400, 100, Bitmap.Config.ARGB_8888);
		ubitmap = Bitmap.createBitmap(400,100, Bitmap.Config.ARGB_8888);
		canvas = new Canvas(bitmap);
		ucanvas = new Canvas(ubitmap);
		paint = new Paint();
		upaint = new Paint();
		
		FilteredView.setImageBitmap(bitmap);
		UnfilteredView.setImageBitmap(ubitmap);
		bandValues = new float[SEEKMAX];
		db = new DBHelper(this);
		
		cb1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (((CheckBox) arg0).isChecked()) {
					if (!isRecording) {
						isRecording = true;
						new AudioServiceTask().execute();
						}
				} else {
					isRecording = false;
				}
			}
		});
		
		cb2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				humanOnly = ((CheckBox)arg0).isChecked();
			}
		});
		
		presets = (Spinner) findViewById(R.id.spinner1);
		presets.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				
				Cursor cs = db.getData(presetNames.get(arg2).getId());
				cs.moveToFirst();
				for(int i=0; i < SEEKMAX; i++) {
					bandValues[i] = cs.getInt(cs.getColumnIndex(DBHelper.PRESET_COLUMN_BAND[i])) / 50 ;
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		populateSpinner();

	}

	private class AudioServiceTask extends AsyncTask<Void, double[], Integer> {

		private boolean flag1;
		

		@Override
		protected Integer doInBackground(Void... arg0) {
			arec = new AudioRecord(MediaRecorder.AudioSource.MIC, 11025,
					AudioFormat.CHANNEL_IN_MONO,
					AudioFormat.ENCODING_PCM_16BIT, bufferSize);
			atrack = new AudioTrack(AudioManager.STREAM_VOICE_CALL, 11025,
					AudioFormat.CHANNEL_OUT_MONO,
					AudioFormat.ENCODING_PCM_16BIT, bufferSize,
					AudioTrack.MODE_STREAM);
			atrack.setPlaybackRate(11025);
			trackID = atrack.getAudioSessionId();
			recordID = arec.getAudioSessionId();
			Log.d("TAG", "Track ID:" + atrack.getAudioSessionId());
			short[] buffer = new short[bufferSize / 2];
			arec.startRecording();
			atrack.play();
			Log.d("TAG", "STARTED");
			Log.d("BUFFER SIZE:", "" + bufferSize);

			FFT_SIZE = 2048 / 2;
			mFFT = new DoubleFFT_1D(FFT_SIZE);
			audioBuffer = new double[2048];
			
			while (isRecording) {
				int bufferReadResult = arec.read(buffer, 0, bufferSize / 2);
				double[] window = new double[bufferReadResult];
				for (int i = 0; i < bufferSize /2 && i < bufferReadResult; i++) {

					window[i] = 0.54 - 0.46 * Math.cos(i * 2 * Math.PI/ (bufferReadResult - 1));
                    audioBuffer[i] = (double) (buffer[i]*window[i]) / 32768.0; // signed
                                                                    // 16
                }     
				mFFT.realForward(audioBuffer);
				if(humanOnly) {
					for (int fftBin = 0; fftBin < FFT_SIZE; fftBin++) {
		
						float frequency = (float) (fftBin * sampleRate)
								/ (float) FFT_SIZE;
						boolean flag = false;
		
						float minFreq = 80;
						float maxFreq = 1499;
		
						if (frequency < minFreq || frequency > maxFreq)
							flag = true;
		
						if (flag) {
							int real = 2 * fftBin;
							int imaginary = 2 * fftBin + 1;
							//int i = (int)Math.floor((frequency-80)/142);
							
							audioBuffer[real] = audioBuffer[real] * 0.25;
							audioBuffer[imaginary] = audioBuffer[imaginary] * 0.25;
						}
					}
				}
		
				// bit
				flag1 = true;
				publishProgress(audioBuffer);
				buffer = applyFilter(buffer, bufferReadResult, 11025);
				atrack.write(buffer, 0, bufferSize / 2);
			}

			return 1;
		}
		
		private short[] applyFilter(short[] buffer, int bufferReadResult,
				int sampleRate) {

			double[] window = new double[bufferReadResult];
			for (int i = 0; i < bufferReadResult; i++) {
				window[i] = 0.54 - 0.46 * Math.cos(i * 2 * Math.PI/ (bufferReadResult - 1)); // hamming window
//				 window[i] = 1; //rectangular window
				// window[i] = 0.5 * (1 -
				// Math.cos(i*2*Math.PI/(bufferReadResult-1))); //hann window
				// window[i] = Math.cos((Math.PI/(bufferReadResult-1)) -
				// Math.PI/2); //cosine window
				// window[i] = 1 - Math.abs(1 - (2/(bufferReadResult-1))); //triangular window
				audioBuffer[i] = (double) (buffer[i] * window[i]) / 32768.0;
			}

			mFFT.realForward(audioBuffer);

			for (int fftBin = 0; fftBin < FFT_SIZE; fftBin++) {

				float frequency = (float) (fftBin * sampleRate)
						/ (float) FFT_SIZE;
				boolean flag = false;

				float minFreq = 80;
				float maxFreq = 1499;

				if (frequency > minFreq && frequency < maxFreq)
					flag = true;

				if (flag) {
					int real = 2 * fftBin;
					int imaginary = 2 * fftBin + 1;
					int i = (int)Math.floor((frequency-80)/142);
					audioBuffer[real] = audioBuffer[real] * bandValues[i];
					audioBuffer[imaginary] = audioBuffer[imaginary] * bandValues[i];
				}
			}
			
			if(humanOnly) {
				for (int fftBin = 0; fftBin < FFT_SIZE; fftBin++) {
	
					float frequency = (float) (fftBin * sampleRate)
							/ (float) FFT_SIZE;
					boolean flag = false;
	
					float minFreq = 80;
					float maxFreq = 1499;
	
					if (frequency < minFreq || frequency > maxFreq)
						flag = true;
	
					if (flag) {
						int real = 2 * fftBin;
						int imaginary = 2 * fftBin + 1;
						//int i = (int)Math.floor((frequency-80)/142);
						
						audioBuffer[real] = audioBuffer[real] * 0.25;
						audioBuffer[imaginary] = audioBuffer[imaginary] * 0.25;
					}
				}
			}
			
			flag1 = false;
			publishProgress(audioBuffer);

			mFFT.realInverse(audioBuffer, true);

			for (int i = 0; i < bufferReadResult; i++) {

				window[i] = 0.54 - 0.46 * Math.cos(i * 2 * Math.PI/ (bufferReadResult - 1)); // hamming window
//				 window[i] = 1; //rectangular window
				// window[i] = 0.5 * (1 -
				// Math.cos(i*2*Math.PI/(bufferReadResult-1))); //hann window
				// window[i] = Math.cos((Math.PI/(bufferReadResult-1)) -
				// Math.PI/2); //cosine window
				// window[i] = 1 - Math.abs(1 - (2/(bufferReadResult-1)));
				// //triangular window
				buffer[i] = (short) (audioBuffer[i] * 32768 / window[i]);
			}

			return buffer;
		}

		@Override
		protected void onProgressUpdate(double[]... audioBuffer) {
			// TODO Auto-generated method stub
			if(flag1) {
			canvas.drawColor(Color.BLUE);
			int freq1 = 80 * FFT_SIZE / 11025;
			int freq2 = 1500 * FFT_SIZE / 11025;
			for (int i = freq1; i < freq2; i++) {
				int x = i * 3;
				int downy = (int) (100 - ((audioBuffer[0][2 * i]) * 10));
				int upy = 100;
				for (int j = 0; j < 3; j++) {
					paint.setColor(Color.RED);
					canvas.drawLine(x + j, downy, x + j, upy, paint);
				}

			}
			FilteredView.invalidate();
			}
			else {
				ucanvas.drawColor(Color.BLACK);
				int freq1 = 80 * FFT_SIZE / 11025;
				int freq2 = 1500 * FFT_SIZE / 11025;
				for (int i = freq1; i < freq2; i++) {
					int x = i * 3;
					int downy = (int) (100 - ((audioBuffer[0][2 * i]) * 10));
					int upy = 100;
					for (int j = 0; j < 3; j++) {
						upaint.setColor(Color.YELLOW);
						ucanvas.drawLine(x + j, downy, x + j, upy, upaint);
					}

				}
				UnfilteredView.invalidate();
			}
			}		

		@Override
		protected void onPostExecute(Integer result) {
			arec.stop();
			arec.release();
			atrack.stop();
			atrack.release();

		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public void onBackPressed() {
	    isRecording=false;
		super.finish();
	}
	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


}
