package com.sasken.voiceeq;

import java.util.ArrayList;
//import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

	public static final String DATABASE_NAME = "VoicePresets.db";
	public static final String PRESETS_TABLE_NAME = "presets";
	public static final String PRESETS_COLUMN_ID = "id";
	public static final String PRESET_COLUMN_NAME = "name";
	public static final String PRESET_COLUMN_BAND[] = {"b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10"};
	


	public DBHelper(Context context)
	{
		super(context, DATABASE_NAME , null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL(
				"create table presets " +
						"(id integer primary key, name text,b1 integer, b2 integer, b3 integer, b4 integer, "
						+ "b5 integer, b6 integer, b7 integer, b8 integer, b9 integer, b10 integer);");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS presets");
		onCreate(db);
	}

	public boolean insertPreset  (String name, int bands[])
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();

		contentValues.put("name", name);
		contentValues.put("b1", bands[0]);
		contentValues.put("b2", bands[1]);
		contentValues.put("b3", bands[2]);
		contentValues.put("b4", bands[3]);
		contentValues.put("b5", bands[4]);
		contentValues.put("b6", bands[5]);
		contentValues.put("b7", bands[6]);
		contentValues.put("b8", bands[7]);
		contentValues.put("b9", bands[8]);
		contentValues.put("b10", bands[9]);

		db.insert("presets", null, contentValues);
		return true;
	}
	public Cursor getData(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor res =  db.rawQuery( "select * from presets where id="+id+"", null );
		return res;
	}
	public int numberOfRows(){
		SQLiteDatabase db = this.getReadableDatabase();
		int numRows = (int) DatabaseUtils.queryNumEntries(db, PRESETS_TABLE_NAME);
		return numRows;
	}
	public boolean updatePreset (Integer id, String name, int bands[])
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("name", name);
		contentValues.put("b1", bands[0]);
		contentValues.put("b2", bands[1]);
		contentValues.put("b3", bands[2]);
		contentValues.put("b4", bands[3]);
		contentValues.put("b5", bands[4]);
		contentValues.put("b6", bands[5]);
		contentValues.put("b7", bands[6]);
		contentValues.put("b8", bands[7]);
		contentValues.put("b9", bands[8]);
		contentValues.put("b10", bands[9]);
		db.update("presets", contentValues, "id = ? ", new String[] { Integer.toString(id) } );
		return true;
	}

	public Integer deletePreset (Integer id)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		return db.delete("presets", 
				"id = ? ", 
				new String[] { Integer.toString(id) });
	}
	public ArrayList getAllPresets()
	{
		ArrayList<SpinnerData> array_list = new ArrayList();
		//hp = new HashMap();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor res =  db.rawQuery( "select id, name from presets", null );
		res.moveToFirst();
		while(res.isAfterLast() == false){
			SpinnerData sd = new SpinnerData(res.getString(res.getColumnIndex(PRESET_COLUMN_NAME)), res.getInt(res.getColumnIndex(PRESETS_COLUMN_ID)));
			array_list.add(sd);
			res.moveToNext();
		}
		return array_list;
	}
}